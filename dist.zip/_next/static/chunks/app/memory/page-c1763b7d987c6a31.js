(self.webpackChunk_N_E=self.webpackChunk_N_E||[]).push([[872],{5855:function(e,t,r){Promise.resolve().then(r.bind(r,5385))},5385:function(e,t,r){"use strict";r.r(t),r.d(t,{default:function(){return d}});var s=r(7437),a=r(2265);/**
 * @license lucide-react v0.379.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let n=(0,r(8030).Z)("Folder",[["path",{d:"M20 20a2 2 0 0 0 2-2V8a2 2 0 0 0-2-2h-7.9a2 2 0 0 1-1.69-.9L9.6 3.9A2 2 0 0 0 7.93 3H4a2 2 0 0 0-2 2v13a2 2 0 0 0 2 2Z",key:"1kt360"}]]);var l=r(4817),i=r(2023),c=r(1592);function d(){let{memoryFiles:e}=(0,c.Z1)(),[t,r]=(0,a.useState)("全部"),[d,o]=(0,a.useState)(null);(0,a.useEffect)(()=>{e.length>0&&!d&&o(e[0])},[e]);let m="全部"===t?e:e.filter(e=>e.category===t);return(0,s.jsx)("div",{className:"space-y-6 pt-[15px]",children:(0,s.jsxs)("div",{className:"grid grid-cols-12 gap-4",children:[(0,s.jsxs)("div",{className:"col-span-2 bg-card border border-custom rounded-xl p-4",children:[(0,s.jsxs)("h3",{className:"text-sm font-bold text-primary mb-3 flex items-center gap-2",children:[(0,s.jsx)(n,{className:"w-4 h-4"}),"分类"]}),(0,s.jsx)("div",{className:"space-y-1",children:["全部","技术文档","工作记录","技术方案"].map(e=>(0,s.jsx)("button",{onClick:()=>r(e),className:"w-full text-left px-3 py-2 rounded-lg text-sm transition-colors ".concat(t===e?"bg-primary text-white":"text-secondary hover:bg-gray-100 dark:hover:bg-gray-800"),children:e},e))})]}),(0,s.jsxs)("div",{className:"col-span-4 bg-card border border-custom rounded-xl p-4",children:[(0,s.jsx)("div",{className:"mb-4",children:(0,s.jsxs)("div",{className:"relative",children:[(0,s.jsx)(l.Z,{className:"absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-tertiary"}),(0,s.jsx)("input",{type:"text",placeholder:"搜索文件...",className:"w-full h-10 pl-10 pr-4 rounded-lg bg-main border border-custom text-sm text-primary placeholder:text-tertiary focus:outline-none focus:ring-2 focus:ring-primary"})]})}),(0,s.jsx)("div",{className:"space-y-2",children:m.map(e=>(0,s.jsx)("button",{onClick:()=>o(e),className:"w-full text-left p-3 rounded-lg transition-colors ".concat((null==d?void 0:d.id)===e.id?"bg-primary/10 border border-primary":"hover:bg-main"),children:(0,s.jsxs)("div",{className:"flex items-start gap-2",children:[(0,s.jsx)(i.Z,{className:"w-4 h-4 text-primary flex-shrink-0 mt-0.5"}),(0,s.jsxs)("div",{className:"flex-1 min-w-0",children:[(0,s.jsx)("p",{className:"text-sm font-medium text-primary truncate",children:e.name}),(0,s.jsxs)("div",{className:"flex items-center gap-2 mt-1",children:[(0,s.jsx)("span",{className:"text-xs text-tertiary",children:e.size}),(0,s.jsx)("span",{className:"text-xs text-tertiary",children:"\xb7"}),(0,s.jsx)("span",{className:"text-xs text-tertiary",children:e.updatedAt})]})]})]})},e.id))})]}),(0,s.jsx)("div",{className:"col-span-6 bg-card border border-custom rounded-xl p-6",children:d?(0,s.jsxs)(s.Fragment,{children:[(0,s.jsxs)("div",{className:"mb-4",children:[(0,s.jsx)("h3",{className:"text-lg font-bold text-primary",children:d.name}),(0,s.jsxs)("p",{className:"text-xs text-tertiary mt-1",children:[d.category," \xb7 ",d.size," \xb7 更新于 ",d.updatedAt]})]}),(0,s.jsx)("div",{className:"bg-main rounded-lg p-4 font-mono text-sm text-primary min-h-[400px]",children:d.content||"暂无内容"})]}):(0,s.jsx)("div",{className:"flex items-center justify-center h-full min-h-[400px] text-tertiary text-sm",children:"请从左侧选择一个文件"})})]})})}},8030:function(e,t,r){"use strict";r.d(t,{Z:function(){return c}});var s=r(2265);/**
 * @license lucide-react v0.379.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let a=e=>e.replace(/([a-z0-9])([A-Z])/g,"$1-$2").toLowerCase(),n=function(){for(var e=arguments.length,t=Array(e),r=0;r<e;r++)t[r]=arguments[r];return t.filter((e,t,r)=>!!e&&r.indexOf(e)===t).join(" ")};/**
 * @license lucide-react v0.379.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */var l={xmlns:"http://www.w3.org/2000/svg",width:24,height:24,viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:2,strokeLinecap:"round",strokeLinejoin:"round"};/**
 * @license lucide-react v0.379.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let i=(0,s.forwardRef)((e,t)=>{let{color:r="currentColor",size:a=24,strokeWidth:i=2,absoluteStrokeWidth:c,className:d="",children:o,iconNode:m,...x}=e;return(0,s.createElement)("svg",{ref:t,...l,width:a,height:a,stroke:r,strokeWidth:c?24*Number(i)/Number(a):i,className:n("lucide",d),...x},[...m.map(e=>{let[t,r]=e;return(0,s.createElement)(t,r)}),...Array.isArray(o)?o:[o]])}),c=(e,t)=>{let r=(0,s.forwardRef)((r,l)=>{let{className:c,...d}=r;return(0,s.createElement)(i,{ref:l,iconNode:t,className:n("lucide-".concat(a(e)),c),...d})});return r.displayName="".concat(e),r}},2023:function(e,t,r){"use strict";r.d(t,{Z:function(){return s}});/**
 * @license lucide-react v0.379.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let s=(0,r(8030).Z)("FileText",[["path",{d:"M15 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7Z",key:"1rqfz7"}],["path",{d:"M14 2v4a2 2 0 0 0 2 2h4",key:"tnqrlb"}],["path",{d:"M10 9H8",key:"b1mrlr"}],["path",{d:"M16 13H8",key:"t4e002"}],["path",{d:"M16 17H8",key:"z1uh3a"}]])},4817:function(e,t,r){"use strict";r.d(t,{Z:function(){return s}});/**
 * @license lucide-react v0.379.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let s=(0,r(8030).Z)("Search",[["circle",{cx:"11",cy:"11",r:"8",key:"4ej97u"}],["path",{d:"m21 21-4.3-4.3",key:"1qie3q"}]])}},function(e){e.O(0,[592,971,23,744],function(){return e(e.s=5855)}),_N_E=e.O()}]);